package br.com.acobrazil.app.checklist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppChecklistApplicationTests {

	@Test
	void contextLoads() {
	}

}
