package br.com.acobrazil.app.checklist.login;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AutenticacaoService {

	@Autowired
	private AutenticacaoRepository  autenticacaoRepository; 	
	
	//Optional para buscar usuario e senha como filtro personalizado vindo do repositorio
	public Optional<Autenticacao> buscarUsuario(String usuario, String password){
		return autenticacaoRepository.findByUsuarioAndPassword(usuario, password);
		
	}
	
	
	
}
