package br.com.acobrazil.app.checklist.check;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;

import br.com.acobrazil.app.checklist.login.Autenticacao;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @AllArgsConstructor @NoArgsConstructor
@Entity
@Table(name="Rchecklist")
public class CheckList {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	
	@ManyToOne
	@JoinColumn(name = "id_user" , referencedColumnName = "id")
	private Autenticacao autenticacao;
	
	@Column(length = 5)
	private String pneus;
	
	@Column(length = 5)
	private String freios;
	
	@Column(length = 5)
	private String luzes;
	
	@Column(length = 5)
	private String filtroAr;
	
	@Column(length= 5)
	private String statuschecklist;
	
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dtchecklist;
	
	public String getRelato() {
		return relato;
	}


	public void setRelato(String relato) {
		this.relato = relato;
	}


	@Column(length = 100)
	private String relato;


	private String NivelOleo;


	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	public Autenticacao getAutenticacao() {
		return autenticacao;
	}


	public void setAutenticacao(Autenticacao autenticacao) {
		this.autenticacao = autenticacao;
	}


	public String getPneus() {
		return pneus;
	}


	public void setPneus(String pneus) {
		this.pneus = pneus;
	}


	public String getFreios() {
		return freios;
	}


	public void setFreios(String freios) {
		this.freios = freios;
	}


	public String getLuzes() {
		return luzes;
	}


	public void setLuzes(String luzes) {
		this.luzes = luzes;
	}

	public String getNivelOleo() {
		return NivelOleo;
	}


	public void setNivelOleo(String nivelOleo) {
		this.NivelOleo= nivelOleo;
	}
	
	public String getfiltroAr() {
		return filtroAr;
	}


	public void setFiltroAr(String filtroAr) {
		this.filtroAr= filtroAr;
	}
	
	public String getStatuschecklist() {
		return statuschecklist;
	}


	public void setStatuschecklist(String statuschecklist) {
		this.statuschecklist = statuschecklist;
	}


	public LocalDate getDtchecklist() {
		return dtchecklist;
	}


	public void setDtchecklist(LocalDate dtchecklist) {
		this.dtchecklist = dtchecklist;
	}

	
}
