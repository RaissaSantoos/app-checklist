package br.com.acobrazil.app.checklist.check;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/checklist")
public class CheckListController {
	
	
	@Autowired
	private CheckListService checkListService;
	

	@GetMapping("/{userId}")
	public ResponseEntity<List<CheckList>> listarPorUsuario(@PathVariable Integer userId) {
	    List<CheckList> checklists = checkListService.listarPorUserId(userId);

	    if (checklists.isEmpty()) {
	        return ResponseEntity.noContent().build(); 
	    }

	    return ResponseEntity.ok(checklists);
	}

	
	
	@PostMapping
	public ResponseEntity<CheckList> salvarCheck(@RequestBody CheckList list){
		CheckList novoCheck = checkListService.salvar(list);
		
		return ResponseEntity.status(HttpStatus.CREATED).body(novoCheck);
	}
	
	
	@PatchMapping("/{id}")
	public ResponseEntity<CheckList> alterarParcial(@PathVariable Integer id, @RequestBody CheckList lista) {
	    return checkListService.salvarParcial(id, lista);
	}

}
