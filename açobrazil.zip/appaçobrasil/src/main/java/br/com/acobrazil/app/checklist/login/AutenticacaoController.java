package br.com.acobrazil.app.checklist.login;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/login")
public class AutenticacaoController {

	@Autowired
	private AutenticacaoService autenticacaoService;

	@GetMapping("/usuario")
	public ResponseEntity<Autenticacao> buscarLogin(@RequestParam String usuario, @RequestParam String password) {
	    Optional<Autenticacao> loginUser = autenticacaoService.buscarUsuario(usuario, password);
	    
	    return loginUser.map(ResponseEntity::ok)
	                    .orElseGet(() -> ResponseEntity.notFound().build());
	}


}
