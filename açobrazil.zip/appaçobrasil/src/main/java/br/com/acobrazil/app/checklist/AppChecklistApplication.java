package br.com.acobrazil.app.checklist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppChecklistApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppChecklistApplication.class, args);
	}

}
