package br.com.acobrazil.app.checklist.check;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import br.com.acobrazil.app.checklist.login.Autenticacao;
import br.com.acobrazil.app.checklist.login.AutenticacaoRepository;

@Service
public class CheckListService {

	@Autowired
	private CheckListRepository checkListRepository;

	@Autowired
	private AutenticacaoRepository autenticacaoRepository;
	
	
	public List<CheckList> listarPorUserId(Integer userId) {
	    return checkListRepository.findByAutenticacaoId(userId);
	}



	// METODO DE SALVAR A O CHECKLIST
	public CheckList salvar(CheckList checkList) {
		Integer userId = checkList.getAutenticacao().getId();

		Autenticacao autenticacao = autenticacaoRepository.findById(userId)
				.orElseThrow(() -> new RuntimeException("Usuário não encontrado"));

		checkList.setAutenticacao(autenticacao);

		return checkListRepository.save(checkList);
	}

	
	//METODO PARA SALVAR PARCIAL
	public ResponseEntity<CheckList> salvarParcial(Integer id, CheckList checkList) {
		CheckList existente = checkListRepository.findById(id)
				.orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "CheckList não encontrado"));

		if (checkList.getStatuschecklist() != null) {
			existente.setStatuschecklist(checkList.getStatuschecklist());
		}
		
		
		if (checkList.getRelato() != null) {
			existente.setRelato(checkList.getRelato());
		}
		
		
		CheckList atualizado = checkListRepository.save(existente);
		return ResponseEntity.ok(atualizado);
	}

}
