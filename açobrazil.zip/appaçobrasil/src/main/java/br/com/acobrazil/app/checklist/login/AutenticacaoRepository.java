package br.com.acobrazil.app.checklist.login;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AutenticacaoRepository extends JpaRepository<Autenticacao, Integer> {

	@Query(value ="""
		    SELECT a.id, a.username, a.password 
		    FROM jloginuser a 
		    WHERE LOWER(a.username) = LOWER(:username) AND a.password = :password
		""", nativeQuery = true)
		Optional<Autenticacao> findByUsuarioAndPassword(@Param("username") String usuario, @Param("password") String password);

}
